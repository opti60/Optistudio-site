'use client'

import { useState, useEffect } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, Code, Zap, BarChart3, Users, Lock, Lightbulb, Check, ChevronDown } from 'lucide-react'

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [activeTab, setActiveTab] = useState(0)
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0)
  const { scrollY } = useScroll()
  const opacity = useTransform(scrollY, [0, 300], [1, 0])

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // ============ NAVIGATION ============
  const Navigation = () => (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'glass border-b border-white/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        {/* Logo */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="text-2xl font-bold gradient-text"
        >
          OptiStudio
        </motion.div>

        {/* Menu Desktop */}
        <div className="hidden md:flex gap-8">
          {['Services', 'Réalisations', 'Processus', 'FAQ', 'Contact'].map((item) => (
            <motion.a
              key={item}
              href={`#${item.toLowerCase()}`}
              whileHover={{ color: '#3b82f6' }}
              className="text-sm font-medium text-gray-300 hover:text-white transition"
            >
              {item}
            </motion.a>
          ))}
        </div>

        {/* CTA Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-accent-blue hover:bg-blue-600 text-white px-6 py-2 rounded-lg font-medium transition"
        >
          Devis Gratuit
        </motion.button>
      </div>
    </motion.nav>
  )

  // ============ HERO ============
  const Hero = () => (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Animated Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-96 h-96 bg-accent-blue/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent-cyan/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="max-w-6xl mx-auto px-6 text-center">
        {/* Tagline */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-block mb-6"
        >
          <span className="text-sm font-semibold text-accent-blue uppercase tracking-wider">
            ✨ La nouvelle génération d'agence web
          </span>
        </motion.div>

        {/* Main Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-6xl md:text-7xl font-bold mb-6 leading-tight"
        >
          Un site web{' '}
          <span className="gradient-text">automatisé par l'IA</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto"
        >
          Créez un site web premium en quelques jours, pas en mois. Notre équipe d'agents IA conçoit, développe et optimise votre présence en ligne.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
        >
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(59, 130, 246, 0.4)' }}
            whileTap={{ scale: 0.95 }}
            className="bg-accent-blue hover:bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold flex items-center justify-center gap-2 transition"
          >
            Demander un Devis Gratuit <ArrowRight size={20} />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="glass text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/10 transition"
          >
            Voir nos réalisations
          </motion.button>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-8 justify-center text-sm text-gray-400"
        >
          <div className="flex items-center gap-2">
            <Lock size={16} className="text-accent-blue" />
            <span>Sécurité garantie</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap size={16} className="text-accent-blue" />
            <span>Résultats en 48h</span>
          </div>
          <div className="flex items-center gap-2">
            <Users size={16} className="text-accent-blue" />
            <span>Support 24/7</span>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
      >
        <ChevronDown size={24} className="text-accent-blue" />
      </motion.div>
    </section>
  )

  // ============ SERVICES ============
  const Services = () => {
    const services = [
      {
        icon: Code,
        title: 'Création Web Premium',
        description: 'Sites ultra-modernes avec animations fluides, responsive et SEO optimisés.',
      },
      {
        icon: Zap,
        title: 'Automatisation IA',
        description: 'Agents IA pour la prospection, le support client et la gestion de projets.',
      },
      {
        icon: BarChart3,
        title: 'Optimisation Conversion',
        description: 'Augmentez vos ventes avec une stratégie data-driven et des CTA optimisés.',
      },
      {
        icon: Lightbulb,
        title: 'Stratégie Digital',
        description: 'Conseils d\'experts pour transformer votre présence en ligne.',
      },
    ]

    return (
      <section id="services" className="py-24 px-6 bg-dark-secondary/50">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold mb-4">
              Ce que nous offrons
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Une suite complète de services pour transformer votre vision en réalité
            </p>
          </motion.div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, idx) => {
              const Icon = service.icon
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: idx * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -10, boxShadow: '0 0 30px rgba(59, 130, 246, 0.2)' }}
                  className="glass p-8 rounded-2xl border border-white/10 hover:border-accent-blue/50 transition group"
                >
                  <div className="bg-accent-blue/20 rounded-lg p-4 w-fit mb-4 group-hover:bg-accent-blue/30 transition">
                    <Icon size={32} className="text-accent-blue" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
                  <p className="text-gray-400">{service.description}</p>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>
    )
  }

  // ============ PROCESSUS ============
  const Processus = () => {
    const steps = [
      {
        number: '01',
        title: 'Consultation',
        description: 'Nos agents IA comprennent vos besoins spécifiques',
        time: '24h',
      },
      {
        number: '02',
        title: 'Maquette Personnalisée',
        description: 'Création d\'une maquette de votre futur site',
        time: '48h',
      },
      {
        number: '03',
        title: 'Développement',
        description: 'Création rapide et efficace de votre site',
        time: '1-2 semaines',
      },
      {
        number: '04',
        title: 'Lancement & Support',
        description: 'Mise en ligne et support continu 24/7',
        time: 'Continu',
      },
    ]

    return (
      <section id="processus" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold mb-4">Notre processus</h2>
            <p className="text-xl text-gray-400">De l'idée au lancement en quelques semaines</p>
          </motion.div>

          {/* Steps */}
          <div className="space-y-8">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="flex gap-8"
              >
                {/* Number */}
                <div className="flex-shrink-0">
                  <div className="glass p-6 rounded-2xl border border-accent-blue/50 w-24 h-24 flex items-center justify-center">
                    <span className="text-3xl font-bold gradient-text">{step.number}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-grow flex flex-col justify-center">
                  <h3 className="text-2xl font-bold mb-2">{step.title}</h3>
                  <p className="text-gray-400 mb-3">{step.description}</p>
                  <div className="text-accent-blue text-sm font-semibold">{step.time}</div>
                </div>

                {/* Line to next */}
                {idx < steps.length - 1 && (
                  <div className="hidden md:block absolute left-24 w-0.5 h-24 bg-gradient-to-b from-accent-blue to-transparent opacity-50" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  // ============ TÉMOIGNAGES ============
  const Testimonials = () => {
    const testimonials = [
      {
        name: 'Marie Dupont',
        role: 'PDG, Tech Solutions',
        text: 'OptiStudio a transformé notre présence en ligne. Le site est magnifique et nous avons déjà multiplié nos leads par 3.',
        avatar: '👩‍💼',
      },
      {
        name: 'Jean Martin',
        role: 'Fondateur, E-commerce Pro',
        text: 'Impressionné par la rapidité et la qualité. L\'équipe IA fonctionne vraiment mieux que prévu.',
        avatar: '👨‍💼',
      },
      {
        name: 'Sophie Bernard',
        role: 'Directrice Marketing, StartUp AI',
        text: 'Un vrai gain de temps. Nous avons pu nous concentrer sur notre stratégie tandis qu\'OptiStudio gérait la technique.',
        avatar: '👩‍💼',
      },
    ]

    return (
      <section className="py-24 px-6 bg-dark-secondary/50">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold mb-4">Témoignages clients</h2>
            <p className="text-xl text-gray-400">Ils nous font confiance</p>
          </motion.div>

          {/* Testimonials Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="glass p-8 rounded-2xl border border-white/10"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="text-4xl">{testimonial.avatar}</div>
                  <div>
                    <h4 className="font-bold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-400">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-300 italic">"{testimonial.text}"</p>
                <div className="mt-4 flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-accent-blue">⭐</span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  // ============ FAQ ============
  const FAQ = () => {
    const faqs = [
      {
        question: 'Combien de temps pour créer mon site ?',
        answer: 'Généralement 1 à 2 semaines après validation de la maquette. Notre processus est rapide grâce à l\'IA.',
      },
      {
        question: 'Puis-je modifier mon site après ?',
        answer: 'Bien sûr ! Nous vous fournissons un dashboard intuitif et un support 24/7 pour toutes les modifications.',
      },
      {
        question: 'Quel est le coût ?',
        answer: 'Les devis sont personnalisés selon vos besoins. Demandez un devis gratuit et sans engagement.',
      },
      {
        question: 'Incluez-vous le SEO ?',
        answer: 'Oui, tous nos sites sont optimisés SEO d\'origine. Google Analytics et Search Console intégrés.',
      },
      {
        question: 'Disposez-vous d\'un support après lancement ?',
        answer: 'Oui, support complet 24/7 pendant 6 mois minimum après lancement, puis optionnel.',
      },
      {
        question: 'Puis-je intégrer ma propre équipe ?',
        answer: 'Absolument. Nous formons votre équipe et vous donnons accès à tous les outils nécessaires.',
      },
    ]

    return (
      <section id="faq" className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold mb-4">Questions fréquentes</h2>
            <p className="text-xl text-gray-400">Vous avez des doutes ?</p>
          </motion.div>

          {/* FAQ Items */}
          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.05 }}
                viewport={{ once: true }}
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                  className="w-full glass p-6 rounded-2xl border border-white/10 hover:border-accent-blue/50 text-left transition flex justify-between items-center"
                >
                  <h3 className="font-bold text-lg">{faq.question}</h3>
                  <motion.div
                    animate={{ rotate: expandedFaq === idx ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ChevronDown size={20} />
                  </motion.div>
                </button>
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{
                    height: expandedFaq === idx ? 'auto' : 0,
                    opacity: expandedFaq === idx ? 1 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="glass p-6 rounded-2xl border border-white/10 border-t-0 text-gray-300">
                    {faq.answer}
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  // ============ CTA FINAL ============
  const FinalCTA = () => (
    <section className="py-24 px-6 relative overflow-hidden">
      {/* Background blur */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-accent-blue/20 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="max-w-2xl mx-auto text-center"
      >
        <h2 className="text-5xl font-bold mb-6">Prêt à transformer votre présence en ligne ?</h2>
        <p className="text-xl text-gray-300 mb-8">
          Demandez un devis gratuit et découvrez comment OptiStudio peut créer votre site web futuriste.
        </p>
        <motion.button
          whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(59, 130, 246, 0.5)' }}
          whileTap={{ scale: 0.95 }}
          className="bg-accent-blue hover:bg-blue-600 text-white px-10 py-5 rounded-lg font-bold text-lg transition inline-flex items-center gap-3"
        >
          Demander un Devis Gratuit <ArrowRight size={24} />
        </motion.button>
      </motion.div>
    </section>
  )

  // ============ FOOTER ============
  const Footer = () => (
    <footer className="border-t border-white/10 py-12 px-6 bg-dark-secondary/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold gradient-text mb-4">OptiStudio</h3>
            <p className="text-gray-400">Agence web nouvelle génération, automatisée par l'IA.</p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-bold mb-4">Navigation</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#services" className="hover:text-white transition">Services</a></li>
              <li><a href="#processus" className="hover:text-white transition">Processus</a></li>
              <li><a href="#faq" className="hover:text-white transition">FAQ</a></li>
            </ul>
          </div>

          {/* Légal */}
          <div>
            <h4 className="font-bold mb-4">Légal</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition">Mentions légales</a></li>
              <li><a href="#" className="hover:text-white transition">Confidentialité</a></li>
              <li><a href="#" className="hover:text-white transition">CGU</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold mb-4">Contact</h4>
            <p className="text-gray-400 mb-2">contact@optistudio.fr</p>
            <p className="text-gray-400">+33 1 XX XX XX XX</p>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/10 pt-8 text-center text-gray-400">
          <p>© 2024 OptiStudio. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  )

  return (
    <main>
      <Navigation />
      <Hero />
      <Services />
      <Processus />
      <Testimonials />
      <FAQ />
      <FinalCTA />
      <Footer />
    </main>
  )
}
