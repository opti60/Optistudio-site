import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'OptiStudio - Agence Web Nouvelle Génération',
  description: 'Créez un site web premium et automatisé grâce à nos agents IA. Devis gratuit en quelques minutes.',
  keywords: 'agence web, site web, création site, design web, IA, automation',
  openGraph: {
    title: 'OptiStudio - Agence Web Nouvelle Génération',
    description: 'Créez un site web premium et automatisé grâce à nos agents IA.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
